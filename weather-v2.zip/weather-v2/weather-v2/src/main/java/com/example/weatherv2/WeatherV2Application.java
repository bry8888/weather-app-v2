package com.example.weatherv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherV2Application {

	public static void main(String[] args) {
		SpringApplication.run(WeatherV2Application.class, args);
	}

}
